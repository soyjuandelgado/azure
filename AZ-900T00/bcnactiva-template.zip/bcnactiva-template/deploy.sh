#!/usr/bin/env bash
# Despliega la plantilla BcnActiva adaptada en un entorno Azure nuevo.
# Uso: ./deploy.sh <appName> [rg] [sku] [location]
# Requiere sesión az activa (az login) y permisos de Contributor en la suscripción.
set -euo pipefail

APP_NAME="${1:?Uso: deploy.sh <appName> [rgName] [sku] [location]}"
RG="${2:-${APP_NAME}-rg}"
SKU="${3:-S1}"   # política lab: F1,D1,B1,B2,B3,S1,Y1 (P0v4 denegado)
LOC="${4:-spaincentral}"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "==> Verificando suscripción activa"
az account show --query "{sub:name,id:state}" -o table

echo "==> Creando resource group $RG en $LOC (si no existe)"
az group create -n "$RG" -l "$LOC" -o none

echo "==> Validando plantilla"
az deployment group validate -g "$RG" \
  --template-file "$HERE/azuredeploy.json" \
  --parameters appName="$APP_NAME" sku="$SKU" location="$LOC" \
  --query "[0].status" -o tsv

echo "==> Desplegando"
az deployment group create -g "$RG" \
  --template-file "$HERE/azuredeploy.json" \
  --parameters appName="$APP_NAME" sku="$SKU" location="$LOC" \
  --query "properties.outputs" -o json

echo "==> URLs del entorno"
az webapp show -g "$RG" -n "$(echo "$APP_NAME" | tr '[:upper:]' '[:lower:]')" \
  --query "defaultHostname" -o tsv
